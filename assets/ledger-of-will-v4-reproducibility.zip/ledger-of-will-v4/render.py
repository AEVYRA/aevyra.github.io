#!/usr/bin/env python3
"""Render the manuscript as HTML using Python-Markdown, pymdownx and MathJax.

Usage: python render.py manuscript.md /path/to/tex-svg.js output.html
MathJax 3.2.2: https://cdn.jsdelivr.net/npm/mathjax@3.2.2/es5/tex-svg.js
PDF: print the resulting file with Chromium after data-math-ready='true'.
"""
import html
from pathlib import Path
import re
import sys
import markdown

source, mathjax, output = map(Path, sys.argv[1:])
raw = source.read_text()
body = re.sub(r'\A---\n.*?\n---\n', '', raw, count=1, flags=re.S)
body = markdown.markdown(body, extensions=['tables', 'pymdownx.arithmatex'],
    extension_configs={'pymdownx.arithmatex': {'generic': True}})
css = '''
@page {size:A4; margin:19mm 20mm 19mm; @bottom-center {content:counter(page); font-size:9pt;}}
* {box-sizing:border-box;} body {font-family:"Times New Roman", "Liberation Serif",serif;font-size:11pt;line-height:1.28;color:#111;max-width:170mm;margin:0 auto;}
h1 {font-size:24pt; text-align:center;margin:10mm 0 3mm; font-weight:normal;}
h1 + h2 {font-size:15pt;text-align:center;margin:0 0 7mm;font-weight:normal;}
h1 + h2 + p {text-align:center;font-size:10pt;margin-bottom:8mm;}
h2 {font-size:14pt;margin:6mm 0 2.5mm;break-after:avoid;}
h3 {font-size:11.5pt;margin:4mm 0 2mm;break-after:avoid;}
p {margin:0 0 2.5mm;text-align:justify;orphans:3;widows:3;}
li {margin-bottom:1.5mm;} a {color:#18365a;text-decoration:none;overflow-wrap:anywhere;}
table {border-collapse:collapse;width:100%;font-size:9pt;margin:4mm 0;}
th,td {padding:1.6mm 2mm;border-bottom:0.3pt solid #aaa;text-align:left;vertical-align:top;}
thead {display:table-header-group;} tr {break-inside:avoid;}
.arithmatex {break-inside:avoid;} mjx-container[display="true"] {margin:3mm 0 !important;}
#abstract {text-align:center;} .abstract {margin:0 7mm;font-size:10.5pt;}
.references p {font-size:9.5pt;line-height:1.2;text-align:left;break-inside:avoid;}
@media screen {body{padding:24px;} }
'''
body = body.replace('<h3>Abstract</h3>','<h3 id="abstract">Abstract</h3><div class="abstract">',1)
body = body.replace('<p><strong>Keywords:', '</div><p><strong>Keywords:',1)
body = body.replace('<h2>References</h2>', '<h2>References</h2><div class="references">') + '</div>'
config = r'''window.MathJax={tex:{inlineMath:[['\\(','\\)']],displayMath:[['\\[','\\]']]},svg:{fontCache:'global'},startup:{ready:()=>{MathJax.startup.defaultReady();MathJax.startup.promise.then(()=>{document.documentElement.setAttribute('data-math-ready','true');});}}};'''
# Inline the pinned renderer so neither printing nor reading needs a network.
script = mathjax.read_text().replace('</script', '<\\/script')
page = '<!DOCTYPE html><html lang="en"><head><meta charset="utf-8"><title>The Ledger of Will</title><style>'+css+'</style><script>'+config+'</script><script>'+script+'</script></head><body>'+body+'</body></html>'
output.write_text(page)
print(output)
