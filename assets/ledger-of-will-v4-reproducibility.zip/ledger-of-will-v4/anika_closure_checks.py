#!/usr/bin/env python3
"""Checks for a proposed addition to Ledger v4 §4.3: sufficiency closed under
iterated revision. Standard library only; finite constructions, no LLM claims.

For finite histories H, revision maps J_z: H -> H and targets T_d, define
  h ~D h'  iff  T_d(h) = T_d(h') for all d                  (v4, Prop. 2)
  h ~* h'  iff  T_d(J_u h) = T_d(J_u h') for all d and words u (Nerode-type)
Claims checked:
  C1  ~* is the coarsest partition that refines ~D and is a congruence
      (h ~* h' => J_z h ~* J_z h'), i.e. admits a state update J^_z.
  C2  ~* can be strictly finer than ~D (v4 §5.1 is such a case).
  C3  At most K*-1 distinguishing tests (u,d) separate all K* classes
      (Moore partition refinement adds >= 1 class per new test).
  C4  Monotonicity: if rho' = f o rho then every demand answerable from
      rho' is answerable from rho (reachable-law sets shrink under reduction).
"""
import itertools
import random


def classes(H, key):
    out = {}
    for h in H:
        out.setdefault(key(h), []).append(h)
    return list(out.values())


def refine(H, J, T):
    """Moore refinement. Returns (block_of, tests) with tests = words used."""
    words = [()]  # the empty word: current targets
    def sig(h, ws):
        return tuple(tuple(t(apply(J, u, h)) for t in T) for u in ws)
    while True:
        blocks = classes(H, lambda h: sig(h, words))
        # try to split with one more symbol prepended to an existing word
        grown = False
        for u in list(words):
            for z in J:
                w = (z,) + u
                if w in words:
                    continue
                if len(classes(H, lambda h: sig(h, words + [w]))) > len(blocks):
                    words.append(w); grown = True; break
            if grown:
                break
        if not grown:
            return {h: i for i, b in enumerate(blocks) for h in b}, words


def apply(J, u, h):
    for z in u:
        h = J[z][h]
    return h


def is_congruence(H, J, block):
    return all(block[J[z][h]] == block[J[z][g]]
               for z in J for h in H for g in H if block[h] == block[g])


def nerode_bruteforce(H, J, T, depth):
    ws = [w for n in range(depth + 1) for w in itertools.product(list(J), repeat=n)]
    key = lambda h: tuple(tuple(t(apply(J, w, h)) for t in T) for w in ws)
    return classes(H, key)


def main():
    # C2 on the v4 §5.1 example: histories carry features and a current law.
    # h = (features of A, law index); revision 'r' switches the law 0 -> 1.
    H = [((1, 1), 0), ((1, -1), 0), ((1, 1), 1), ((1, -1), 1)]
    W = [(1, 0), (0, 1)]
    best = lambda h: 'A' if sum(a * b for a, b in zip(W[h[1]], h[0])) > 0 else 'B'
    J = {'r': {h: (h[0], 1) for h in H}}
    T = [best]
    blocks_D = classes(H, lambda h: best(h))
    block, tests = refine(H, J, T)
    kstar = len(set(block.values()))
    assert is_congruence(H, J, block)
    assert len(blocks_D) == 2 and kstar == 3, (blocks_D, kstar)
    print('C2 v4 §5.1: |H/~D| =', len(blocks_D), ' |H/~*| =', kstar, ' tests =', tests)

    rng = random.Random(20260925)
    trials = 0
    for _ in range(3000):
        n, nz, nt, vals = rng.randint(2, 9), rng.randint(1, 3), rng.randint(1, 2), rng.randint(2, 3)
        H = list(range(n))
        J = {z: {h: rng.randrange(n) for h in H} for z in range(nz)}
        tables = [{h: rng.randrange(vals) for h in H} for _ in range(nt)]
        T = [lambda h, t=t: t[h] for t in tables]
        block, tests = refine(H, J, T)
        k = len(set(block.values()))
        # C1: congruence, refines ~D, and equals brute-force Nerode classes
        assert is_congruence(H, J, block)
        assert all(block[h] != block[g] for h in H for g in H
                   if any(t(h) != t(g) for t in T))
        brute = nerode_bruteforce(H, J, T, depth=n)
        assert sorted(map(sorted, brute)) == sorted(map(sorted, classes(H, lambda h: block[h])))
        # C1 coarsest: any congruence refining ~D refines ~* (check merged pairs)
        # (a pair in the same ~* block agrees on every future target, so no
        #  congruence refining ~D needs to separate it; brute force above
        #  confirms ~* is exactly the Nerode relation.)
        # C3: number of distinguishing tests beyond the empty word <= K*-1
        assert len(tests) - 1 <= max(0, k - len(classes(H, lambda h: tuple(t(h) for t in T))))
        assert len(tests) <= k
        trials += 1
    print('C1,C3 random finite systems checked:', trials)

    # C4 monotonicity on all maps of a 4-element history set into 3 states
    H = list(range(4))
    target = {0: 0, 1: 1, 2: 1, 3: 0}
    ok = 0
    for rho in itertools.product(range(3), repeat=4):
        for f in itertools.product(range(3), repeat=3):
            rho2 = tuple(f[s] for s in rho)
            suff = lambda r: all(target[h] == target[g] for h in H for g in H if r[h] == r[g])
            assert not suff(rho2) or suff(rho)
            ok += 1
    print('C4 monotonicity cases:', ok)


if __name__ == '__main__':
    main()
