#!/usr/bin/env python3
"""Independent finite review checks, Sofia, 2026-09-25.

Uses Anika's witness algorithm; checks against pair distinguishability rather
than enumerating words. No LLM or biological claims. Standard library only.
"""
import itertools
import json
import random
from collections import Counter, defaultdict
from fractions import Fraction

from anika_closure_checks import apply, classes, is_congruence, refine


def distinguishable(H, J, T):
    """Least pair relation seeded by output inequality and closed backwards."""
    pairs = {(h, g) for h in H for g in H if any(t(h) != t(g) for t in T)}
    while True:
        added = {(h, g) for h in H for g in H
                 if any((j[h], j[g]) in pairs for j in J.values())}
        enlarged = pairs | added
        if enlarged == pairs:
            return pairs
        pairs = enlarged


def partitions(xs):
    if not xs:
        yield []
        return
    x, *tail = xs
    for p in partitions(tail):
        yield [[x]] + p
        for i in range(len(p)):
            yield p[:i] + [[x] + p[i]] + p[i+1:]


def check(H, J, T, exhaustive_partitions=False):
    block, words = refine(H, J, T)
    distinct = distinguishable(H, J, T)
    assert all((block[h] != block[g]) == ((h, g) in distinct) for h in H for g in H)
    assert is_congruence(H, J, block)
    k = len(classes(H, lambda h: tuple(t(h) for t in T)))
    kstar = len(set(block.values()))
    assert len(words) - 1 <= kstar - k
    if exhaustive_partitions:
        for p in partitions(H):
            rho = {h: i for i, b in enumerate(p) for h in b}
            sufficient = all(block[h] == block[g] for h in H for g in H if rho[h] == rho[g])
            current_ok = all(all(t(h) == t(g) for t in T)
                             for h in H for g in H if rho[h] == rho[g])
            if current_ok and is_congruence(H, J, rho):
                assert sufficient  # coarsest invariant output-preserving partition
            if not sufficient:
                continue
            representatives = {i: b[0] for i, b in enumerate(p)}
            update = {z: {i: rho[j[h]] for i, h in representatives.items()}
                      for z, j in J.items()}
            # Product simulation: all reachable retained/full-state pairs.
            todo = {(rho[h], h) for h in H}
            seen = set()
            while todo:
                state, h = todo.pop()
                if (state, h) in seen:
                    continue
                seen.add((state, h))
                assert all(t(representatives[state]) == t(h) for t in T)
                todo.update((update[z][state], j[h]) for z, j in J.items())
    return k, kstar, len(words) - 1


def main():
    H = list(range(3))
    count = 0
    for maps in itertools.product(list(itertools.product(H, repeat=3)), repeat=2):
        J = {z: dict(enumerate(m)) for z, m in enumerate(maps)}
        for target in itertools.product(range(2), repeat=3):
            check(H, J, [lambda h, t=target: t[h]], True)
            count += 1
    assert count == 5832
    rng = random.Random(20260926)
    random_count = 3000
    for _ in range(random_count):
        H = list(range(rng.randint(2, 9)))
        J = {z: {h: rng.choice(H) for h in H} for z in range(rng.randint(1, 3))}
        tables = [{h: rng.randrange(3) for h in H} for _ in range(rng.randint(1, 3))]
        check(H, J, [lambda h, t=t: t[h] for t in tables])

    H = [(sign, law) for sign in (1, -1) for law in (0, 1)]
    J = {'r': {h: (h[0], 1) for h in H}}
    k, kstar, nw = check(H, J, [lambda h: 'A' if h[1] == 0 or h[0] == 1 else 'B'])
    assert (k, kstar, nw) == (2, 3, 1)
    H = [0, 1, 2]
    rho = {0: 'a', 1: 'a', 2: 'b'}
    J = {'r': {0: 0, 1: 2, 2: 2}}
    assert check(H, J, [lambda h: 0], True)[:2] == (1, 1)
    assert not is_congruence(H, J, rho)

    # Partial replay: all three events are incomparable, only two full paths.
    U = {'a': {'0': 'a', 'cb': 'R'}, 'b': {'a': 'ab', 'c': 'cb'},
         'c': {'0': 'c', 'ab': 'L'}}
    def replay(word, state='0'):
        for e in word:
            state = U[e].get(state)
            if state is None:
                return None
        return state
    reachable = {replay(w) for n in range(4) for w in itertools.permutations(U, n)} - {None}
    weak = all(replay((a,b), s) is None or replay((b,a), s) is None
               or replay((a,b), s) == replay((b,a), s)
               for s in reachable for a,b in itertools.permutations(U, 2))
    full = {''.join(w): replay(w) for w in itertools.permutations(U) if replay(w) is not None}
    assert weak and full == {'abc': 'L', 'cba': 'R'}

    def risk(signals, labels):
        groups = defaultdict(Counter)
        for s, y in zip(signals, labels):
            groups[s][y] += 1
        formula = 1 - sum(Fraction(max(g.values()), len(labels)) for g in groups.values())
        signals_unique = list(groups)
        best = min(Fraction(sum(choice[signals_unique.index(s)] != y
                                for s, y in zip(signals, labels)), len(labels))
                   for choice in itertools.product(set(labels), repeat=len(groups)))
        assert formula == best
        return str(best)
    assert risk([0, 0], [0, 1]) == '1/2'
    assert risk([0, 0, 0], [0, 1, 2]) == '2/3'
    assert risk([0, 1, 2], [0, 1, 2]) == '0'

    # Explicit replacement semantics, immutable history, reads do not append.
    events = [('episode', 1, +1)]
    def fold():
        active = {}
        for lineage, version, value in events:
            if lineage not in active or version > active[lineage][0]:
                active[lineage] = version, value
        return sum(v for _, v in active.values())
    for _ in range(10):
        assert fold() == 1 and len(events) == 1
    events.append(('episode', 2, -1))
    for _ in range(10):
        assert fold() == -1 and len(events) == 2
    assert sum(e[2] for e in events) == 0 and events[0][2] == 1
    print(json.dumps({
        'exhaustive_three_state_two_revision_binary_target_systems': count,
        'all_five_partitions_checked_per_exhaustive_system': True,
        'independent_seeded_pair_closure_systems': random_count,
        'four_state_extension': {'K': k, 'K_star': kstar, 'additional_words': nw},
        'behavior_preservation_does_not_imply_exact_representation_update': True,
        'weak_partial_commutation_counterexample': full,
        'reader_error_floors': {'two_labels': '1/2', 'three_labels': '2/3', 'revealed_labels': '0'},
        'reconstruction': {'read_count': 20, 'events': 2, 'active_value': -1, 'naive_sum': 0},
        'scope': 'finite constructions only; no model or biological experiment'
    }, indent=2, sort_keys=True))


if __name__ == '__main__':
    main()
