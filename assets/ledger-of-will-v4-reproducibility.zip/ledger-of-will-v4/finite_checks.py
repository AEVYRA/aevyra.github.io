#!/usr/bin/env python3
"""Finite illustrations for Ledger v4; no LLM calls or subject-level claims.

Run from any directory: python3 finite_checks.py > finite-results.json
"""
import itertools
import json
import math
from fractions import Fraction


def sufficient(histories, reduce, targets):
    fibers = {}
    for h in histories:
        target = tuple(f(h) for f in targets)
        s = reduce(h)
        if s in fibers and fibers[s] != target:
            return False
        fibers[s] = target
    return True


def dot(a, b):
    return sum(x * y for x, y in zip(a, b))


def main():
    results = {}
    histories = [((1, 1), (0, 0)), ((1, -1), (0, 0))]
    current = lambda h: tuple(dot((1, 0), a) for a in h)
    revised = lambda h: tuple(dot((0, 1), a) for a in h)
    assert sufficient(histories, current, [current])
    assert not sufficient(histories, current, [revised])
    best_blind_regret = min(
        sum(Fraction(max(revised(h)) - revised(h)[a], 2) for h in histories)
        for a in [0, 1]
    )
    assert best_blind_regret == Fraction(1, 2)
    assert sufficient(histories, lambda h: h, [current, revised])
    results['revaluation'] = {
        'initial_targets': [current(h) for h in histories],
        'revised_targets': [revised(h) for h in histories],
        'merged_state_optimal_expected_regret': str(best_blind_regret),
        'full_feature_expected_regret': 0,
    }

    bits = list(itertools.product([0, 1], repeat=8))
    queries = [lambda h, i=i: h[i] for i in range(8)]
    targets = {tuple(q(h) for q in queries) for h in bits}
    assert len(targets) == 256
    assert not sufficient(bits, lambda h: h[:4], queries)
    results['capacity'] = {'histories': len(bits), 'target_classes': len(targets),
                           'minimum_fixed_width_bits': 8}

    # Exhaustively check all points in the declared finite two-action grid.
    vectors = list(itertools.product([-1.0, 0.0, 1.0], repeat=2))
    weights = [(1., 0.), (0., 1.), (-1., 0.), (0., -1.),
               (math.sqrt(.5), math.sqrt(.5))]
    errors = [(0., 0.), (.75, 0.), (-.75, 0.), (0., .75), (0., -.75)]
    count = 0
    max_ratio = 0.0
    for a, b, ea, eb, w in itertools.product(vectors, vectors, errors, errors, weights):
        truth = [dot(w, a), dot(w, b)]
        est = [dot(w, tuple(x+y for x,y in zip(a, ea))),
               dot(w, tuple(x+y for x,y in zip(b, eb)))]
        chosen = max(range(2), key=lambda i: (est[i], i))
        regret = max(truth) - truth[chosen]
        eps = max(math.hypot(*ea), math.hypot(*eb))
        bound = 2 * math.hypot(*w) * eps
        assert regret <= bound + 1e-12
        if bound: max_ratio = max(max_ratio, regret/bound)
        count += 1
    # Sharp example with explicitly adverse tie-break.
    tight_true, tight_est = [1, -1], [0, 0]
    chosen = max(range(2), key=lambda i: (tight_est[i], i))
    assert max(tight_true)-tight_true[chosen] == 2
    results['regret_bound'] = {'grid_cases': count, 'max_grid_ratio': max_ratio,
                               'tight_case_regret': 2, 'tight_case_bound': 2}

    add, scale = lambda x: x+1, lambda x: 2*x
    assert scale(add(0)) == 2 and add(scale(0)) == 1
    set_results = []
    for order in itertools.permutations(['a', 'b']):
        s = set()
        for item in order: s.add(item)
        set_results.append(sorted(s))
    assert set_results[0] == set_results[1]
    results['replay'] = {'noncommuting': [scale(add(0)), add(scale(0))],
                         'commutative_sets': set_results}

    lr = Fraction(3)
    single = lr / (1+lr)
    duplicated = lr**4 / (1+lr**4)
    assert single == Fraction(3, 4) and duplicated == Fraction(81, 82)
    results['source_replication'] = {'single_source': str(single),
                                     'incorrect_four_independent_copies': str(duplicated),
                                     'source_aware_four_copies': str(single)}

    sources = [frozenset(['a']), frozenset(['a', 'b'])]
    after_retract = lambda h: bool(h - {'a'})
    assert not sufficient(sources, bool, [after_retract])
    assert sufficient(sources, lambda h: h, [after_retract])
    results['revision_witness'] = {'before': [bool(h) for h in sources],
                                   'after_retract_a': [after_retract(h) for h in sources]}

    intentions = [('do-task', 'open'), ('do-task', 'cancelled')]
    fire = lambda h: h[1] == 'open'
    assert not sufficient(intentions, lambda h: h[0], [fire])
    assert sufficient(intentions, lambda h: h[1], [fire])
    results['commitment'] = {'same_initial_text': True,
                             'act_on_trigger': [fire(h) for h in intentions]}

    def mutual_information(pairs):
        counts, zcounts, scounts = {}, {}, {}
        for z, s in pairs:
            counts[z,s] = counts.get((z,s),0)+1
            zcounts[z] = zcounts.get(z,0)+1
            scounts[s] = scounts.get(s,0)+1
        n=len(pairs)
        return sum(c/n * math.log2(c*n/(zcounts[z]*scounts[s]))
                   for (z,s),c in counts.items())
    retained=mutual_information([(0,0),(1,1)])
    forgotten=mutual_information([(0,0),(1,0)])
    assert retained == 1 and forgotten == 0
    results['forgetting'] = {'retained_mutual_information_bits':retained,
                             'constant_state_mutual_information_bits':forgotten,
                             'constant_state_best_recovery_probability':.5}
    print(json.dumps({'scope':'finite algebra and constructed examples only',
                      'all_checks_passed': True,'results':results}, indent=2))


if __name__ == '__main__':
    main()
