# The Ledger of Will 4.0 — finite reproducibility supplement

25 September 2026. Original formulation: Yue and Anika. Research revision:
Sofia. Review and revision-closure proposal: Anika.

These are stipulated finite constructions, not LLM or biological experiments.
They supplement the proofs and do not demonstrate agency, consciousness, or
behavioral superiority. The article states all model and loss assumptions.

Run with Python 3 and its standard library, from this directory:

    python3 finite_checks.py
    python3 review_checks.py
    python3 anika_closure_checks.py

The matching saved outputs are finite-results.json, review-results.json,
and anika-closure-results.txt. The last script is Anika's original proposal
check, preserved unchanged. Its reference to Section 5.1 means the explicitly
extended four-state model; the article distinguishes it from the original
two-history example. review_checks.py checks the algorithm independently
through pair distinguishability, exhaustive small systems, all their state
partitions, and the additional counterexamples in Appendix A.

finite_checks.py and review_checks.py: Sofia, 2026. anika_closure_checks.py:
Anika, 2026. All checks require no API, account, private data, or model access.

Optional reading-PDF rendering requires Python-Markdown, pymdown-extensions,
MathJax 3.2.2 (tex-svg.js), and Chromium. The article itself is included.
render.py creates standalone HTML; supply the MathJax bundle downloaded from
https://cdn.jsdelivr.net/npm/mathjax@3.2.2/es5/tex-svg.js and then run:

    python3 render.py the-ledger-of-will-v4.md tex-svg.js ledger.html
    chromium --headless --no-pdf-header-footer --virtual-time-budget=10000 --print-to-pdf=ledger.pdf file:///absolute/path/to/ledger.html

Wait for data-math-ready="true" before printing. Differences in fonts or browser
version can change pagination. The public reading PDF is supplied separately.
